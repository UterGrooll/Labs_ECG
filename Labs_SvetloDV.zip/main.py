import tkinter as tk
from tkinter import messagebox

from app import AppController
from ui_config import APP_W, APP_H


def main():
    root = tk.Tk()
    AppController(root)

    root.update_idletasks()
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    x = (sw - APP_W) // 2
    y = (sh - APP_H) // 2
    root.geometry(f"{APP_W}x{APP_H}+{x}+{y}")

    def on_close():
        if messagebox.askokcancel("\u0412\u044b\u0445\u043e\u0434", "\u0412\u044b \u0443\u0432\u0435\u0440\u0435\u043d\u044b, \u0447\u0442\u043e \u0445\u043e\u0442\u0438\u0442\u0435 \u0432\u044b\u0439\u0442\u0438?"):
            root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    root.mainloop()


if __name__ == "__main__":
    main()
